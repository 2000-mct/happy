#include "../head/linkedList.h"

int main()
{



	return 0;
}


